import Header from "./components/header";
import NavBar from "./components/navigation";
import Body from "./components/body";
import Footer from "./components/footer";

import "./App.css";

function App() {
  return (
    <>
      <NavBar />
      <Header />
      <Body />
      <Footer />
    </>
  );
}

export default App;
