function footerMain() {
  return (
    <>
      <footer>
        <div>
          <h1>ABOUT US</h1>
          <p>
            A mix of old and new marks USC&apos;s brand of education. The
            missionary spirit is kept alive with the school&apos;s pursuit
            for the latest in science, technology, and the arts. A sense of heritage
            blends well with the Carolinian enthusiasm for the new. And this is
            best shown in the increasingly eclectic look of the
            school&apos;s architecture.
          </p>
        </div>
        <div className="linksfoot">
          <h1>LINKS</h1>
          <p>
            <a href="#">
              <i className="fa fa-globe"></i> &nbsp;Academic Calendar
            </a>
            <a href="#">
              <i className="fa fa-globe"></i> &nbsp;USC Website
            </a>
          </p>
        </div>
        <div className="linksfoot">
          <h1>ISMIS MODULES</h1>
          <p>
            <a href="#">
              <i className="fa fa-code"></i> &nbsp; Administrative Module
            </a>
            <a href="#">
              <i className="fa fa-code"></i> &nbsp;Finance Module
            </a>
          </p>
        </div>
        <div>
          <h1>CONTACT US</h1>
          <p>
            P. del Rosario Street, Cebu City<br></br>Philippines 6000<br></br>
            Phone: +63 (32) 253 1000<br></br>Fax: +63 (32) 255 4341<br></br>
            E-mail: information@usc.edu.ph<br></br>Website: usc.edu.ph
          </p>
        </div>
      </footer>
      <div className="finalFooter">
        2023 © UNIVERSITY OF SAN CARLOS - ISMIS
      </div>
    </>
  );
}

export default footerMain;
