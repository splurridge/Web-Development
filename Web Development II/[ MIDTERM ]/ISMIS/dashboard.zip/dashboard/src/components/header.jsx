function HeaderTop() {
  return (
    <div className="headertop">
      <ul className="menu2">
        <li className="x">Home</li>
        <li className="x dropdown2">
          Features <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <div>
                <i className="fa fa-get-pocket"></i>Enrollment Related
                <i className="fa fa-angle-right"></i>
              </div>

              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Student Enrollment
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Exam Permit
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Student Clearance
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i> Offered Courses
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Student Grades
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>
        <li className="x dropdown2">
          Privacy Policy Statement <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>USC Privacy Policy Statement
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">USC Privacy Policy Statement</a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          Meet CALOY <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Caloy Kiosk Location
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <i className="fa fa-angle-right"></i>
                  <a href="#">Arthur Dingman</a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Caloy Mobile Version
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content2">
                <li>
                  <i className="fa fa-angle-right"></i>
                  <a href="#">Mobile Version</a>
                </li>
              </ul>
            </li>
          </ul>
        </li>
        <li className="x dropdown2">
          SAFAD Magazine <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Lantawan Magazine
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>2020 - Issue 2
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>2021 - Issue 1
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>2021 - Issue 2
                    (September)
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>2022 - Issue 1 (March)
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>2022 - Issue 2
                    (September)
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>SAFAD Facebook Frame
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content2">
                <li>
                  <i className="fa fa-angle-right"></i>
                  <a href="#">SAFAD Facebook Frame</a>
                </li>
              </ul>
            </li>
          </ul>
        </li>
        <li className="x dropdown2">
          Student Task <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Others
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Schedule
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Academic Calendar
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Journals and References
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Prospectus
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Student Application
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Deficiency
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Evaluation
                    Graduation
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Graduation
                    Clearance
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Change of Program
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Same Family
                    Privilege
                  </a>
                </li>

                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Graduation
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Course
                    Accreditation
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply for Course
                    Equivalency
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Enrollment Related
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content3">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Student Enrollment
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Exam Permit
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>View Offered Courses
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>View Study Load
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>View Grades
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>View Lacking Subjects
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Simultaneous
                    Enrollment
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Overload
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Petition/Tutorial
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Partial Course
                    Withdrawal
                  </a>
                </li>

                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Complete Course
                    Withdrawal
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Enrollment Guide
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content2">
                <li>
                  <i className="fa fa-angle-right"></i>
                  <a href="#">USC Enrollment Guide</a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Library Related
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content4">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Library
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>OPAC - Tertiary
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>OPAC - Bed
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Electronic Resources
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Library Announcement
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          Student Services <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Student Manual/Handbook
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>SHS Handbook 2020
                    Edition
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Student Manual Tertiary
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>CLG Trailer
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Carolininan Lifestyle
                    Guide CLG
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Quality Improvement
                    Tool
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Counseling and Development
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content3">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Reach Out to your
                    Counselor
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Programs and Activities
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Campus Ministry
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content5">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Contact a Spiritual
                    Adviser
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          Online Purchase(Textbook Dept) <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Online Purchase
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Textbook/Unfirom/Toga
                    Carting
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          Motor Vehicle Pass <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Sticker Application
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Pass
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>
        <li className="x dropdown2">
          Evaluation <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Evaluation
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Evaluation
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          Administrative <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Campus Entry Application
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Campus Entry
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Facility Utilization
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content3 v2">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Facility
                    Utilization
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          Job Placement <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Job Openings
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>List Of Job Openings
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Job Application Status
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          OSA <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Student Organization
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Application
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Activity Permit
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content3 v3">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Activity Permit
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          Downloadable Forms <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Vice-President for Finance
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Downloadable Forms
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Office of the Registrar
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content3">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Downloadable Forms
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>IRM Office
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content3v2 vvvv">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Downloadable Forms
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Learning Resource Center
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content4">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Downloadable Forms
                  </a>
                </li>
              </ul>
            </li>

            <li className="nested-dropdown m-10">
              <i className="fa fa-get-pocket"></i>Vice-President for
              Administration
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content5v2 vvvv">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Downloadable Forms
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          Promissory Note <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Apply Promissory Note
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Apply Promissory Note
                  </a>
                </li>
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Promisory Note History
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>



        <li className="x dropdown2">
          Send Proof of Payment <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>Send Proof of Payment
              <i className="fa fa-angle-right"></i>
              <ul className="nested-dropdown-content">
                <li>
                  <a href="#">
                    <i className="fa fa-angle-right"></i>Send Proof of Payment
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li className="x dropdown2">
          USC Publishing House <i className="fa fa-angle-down"></i>
          <ul className="dropdown-content2 ldrop">
            <li className="nested-dropdown">
              <i className="fa fa-get-pocket"></i>DIGITAL BOOKS
              <a href="#" className="clearH">
                <i className="fa fa-angle-right"></i>&nbsp;Tertiary Digital
                Books
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  );
}

export default HeaderTop;