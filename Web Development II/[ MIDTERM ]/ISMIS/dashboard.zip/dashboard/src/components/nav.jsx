import headerPicture from "../assets/reportHeader1.png";
import profilePicture from "../assets/profilePic.jpeg";

function NavBar() {
  return (
    <nav className="navbar">
      <div className="logo">
        <img src={headerPicture} height="47" />
      </div>
      <ul className="menu">
        <li>
          <a href="#">
            <i className="fa fa-globe"></i>
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-ban"></i>
          </a>
        </li>
        <li className="separator">|</li>
        <li className="dropdown">
          <span className="imgpic">
            <img src={profilePicture} alt="Profile Pic" className="profile-pic" />
            22104403
          </span>
          <div className="dropdown-content">
            <a href="#">
              <i className="fa fa-user"> </i> My Profile
            </a>
            <a href="#">
              <i className="fa fa-calendar"> </i> Manage Account
            </a>
            <a href="#">
              <i className="fa fa-key"> </i> My Password
            </a>
            <a href="#">
              <i className="fa fa-sign-out"> </i> Logout
            </a>
          </div>
        </li>
      </ul>
    </nav>
  );
}

export default NavBar;
