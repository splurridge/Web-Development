function pCounter() {
  let totalPageCount = 220;
  return (
    <>
      <div className="additionalContent">
        <h2>Showing Page 1 of 15</h2>
      </div>

      <div className="pagination-container">
        <div className="pagination-wrapper">
          <ul className="pagination">
            <li className="active">
              <a href="#">1</a>
            </li>
            <li>
              <a href="#">2</a>
            </li>
            <li>
              <a href="#">3</a>
            </li>
            <li>
              <a href="#">4</a>
            </li>
            <li>
              <a href="#">5</a>
            </li>
            <li>
              <a href="#">6</a>
            </li>
            <li>
              <a href="#">7</a>
            </li>
            <li>
              <a href="#">8</a>
            </li>
            <li>
              <a href="#">9</a>
            </li>
            <li>
              <a href="#">10</a>
            </li>
            <li className="disabled PagedList-ellipses">
              <a>…</a>
            </li>
            <li className="PagedList-skipToNext">
              <a href="#">»</a>
            </li>
            <li className="PagedList-skipToLast">
              <a href="#">»»</a>
            </li>
          </ul>
        </div>

        <div className="counterPage">Total Count : {totalPageCount}</div>
      </div>
    </>
  );
}

export default pCounter;
