import announcementPicture from "../assets/emptyProfilePic.jpeg";

function body() {
  return (
    <div className="mainCont">
      <div className="announcement">
        <div className="timelinecontainer">
          <div className="timeline">
            <div className="posterImage">
              <img src={announcementPicture} alt="" />
            </div>
            <div className="timelineheader">
              <h1>FR. MELCHOR FUERZAS</h1>
              <h2 className="subTitle">VICE PRES FOR ADMINISTRATION OFFICE</h2>
              <h2 className="subTitle">Wednesday, August 30, 2023 2:29 PM</h2>
              <h1 className="title">
              Application for Motor Vehicle Pass Sticker (MVPS) is now open.
              </h1>
              <br></br>
              <p>
              To:  All Tertiary and Basic Education Faculty and Staff, Students, Parents, Concessionaires and Outsourced Contractors. Application for Motor Vehicle Pass Sticker is now
              <br></br>open until September 30, 2023. Please apply and get your gate pass sticker now. No Sticker No entry Policy will be implemented after the application period is ended. 
              </p>
              </div>
            </div>
          </div>
        </div>
    </div>
  );
  }

export default body;
